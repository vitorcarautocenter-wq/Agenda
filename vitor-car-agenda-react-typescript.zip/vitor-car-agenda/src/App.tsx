import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { supabase } from './lib/supabase';

type Appointment = { id: string; cliente: string; veiculo: string; placa: string; servico: string; data: string; horario: string; observacoes: string; status: string };
type Draft = Omit<Appointment, 'id'>;
const today = new Date();
const dateKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const fromKey = (s: string) => { const [y,m,d]=s.split('-').map(Number); return new Date(y,m-1,d); };
const fmt = (d: Date, options: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat('pt-BR', options).format(d);
const emptyDraft = (date: string): Draft => ({ cliente:'', veiculo:'', placa:'', servico:'', data:date, horario:'08:00', observacoes:'', status:'Agendado' });
const services = ['Revisão geral','Troca de óleo e filtros','Alinhamento e balanceamento','Freios','Suspensão','Diagnóstico eletrônico','Motor','Transmissão','Outro serviço'];

export default function App() {
  const [view,setView] = useState(new Date(today.getFullYear(),today.getMonth(),1));
  const [selected,setSelected] = useState(new Date(today));
  const [items,setItems] = useState<Appointment[]>([]);
  const [loading,setLoading] = useState(Boolean(supabase));
  const [error,setError] = useState('');
  const [modal,setModal] = useState(false);
  const [editing,setEditing] = useState<string|null>(null);
  const [draft,setDraft] = useState<Draft>(emptyDraft(dateKey(today)));

  const load = useCallback(async () => {
    if (!supabase) return;
    setLoading(true); setError('');
    const {data,error:err}=await supabase.from('agendamentos').select('*').order('data').order('horario');
    if (err) setError(`Não foi possível carregar os dados: ${err.message}`);
    else setItems((data ?? []).map((x:any)=>({id:x.id,cliente:x.cliente,veiculo:x.veiculo,placa:x.placa??'',servico:x.servico,data:x.data,horario:String(x.horario).slice(0,5),observacoes:x.observacoes??'',status:x.status??'Agendado'})));
    setLoading(false);
  },[]);
  useEffect(()=>{ void load(); },[load]);
  const dayItems=useMemo(()=>items.filter(a=>a.data===dateKey(selected)).sort((a,b)=>a.horario.localeCompare(b.horario)),[items,selected]);
  const monthItems=items.filter(a=>a.data.startsWith(`${view.getFullYear()}-${String(view.getMonth()+1).padStart(2,'0')}`));
  const todayItems=items.filter(a=>a.data===dateKey(today));
  const openNew=()=>{setEditing(null);setDraft(emptyDraft(dateKey(selected)));setModal(true);};
  const openEdit=(a:Appointment)=>{setEditing(a.id);setDraft({cliente:a.cliente,veiculo:a.veiculo,placa:a.placa,servico:a.servico,data:a.data,horario:a.horario,observacoes:a.observacoes,status:a.status});setModal(true);};
  const save=async(e:FormEvent)=>{e.preventDefault();setError('');
    if(supabase){const payload={cliente:draft.cliente.trim(),veiculo:draft.veiculo.trim(),placa:draft.placa.trim().toUpperCase()||null,servico:draft.servico,data:draft.data,horario:draft.horario,observacoes:draft.observacoes.trim()||null,status:draft.status};
      const result=editing?await supabase.from('agendamentos').update(payload).eq('id',editing):await supabase.from('agendamentos').insert(payload);
      if(result.error){setError(`Erro ao salvar: ${result.error.message}`);return;} await load();
    }else{const record:Appointment={...draft,id:editing??crypto.randomUUID()};setItems(old=>editing?old.map(a=>a.id===editing?record:a):[...old,record]);}
    const d=fromKey(draft.data);setSelected(d);setView(new Date(d.getFullYear(),d.getMonth(),1));setModal(false);
  };
  const remove=async(id:string)=>{if(!confirm('Excluir este agendamento?'))return;if(supabase){const {error:err}=await supabase.from('agendamentos').delete().eq('id',id);if(err){setError(`Erro ao excluir: ${err.message}`);return;}await load();}else setItems(old=>old.filter(a=>a.id!==id));};
  const calendarDays=useMemo(()=>{const start=new Date(view.getFullYear(),view.getMonth(),1);start.setDate(1-start.getDay());return Array.from({length:42},(_,i)=>{const d=new Date(start);d.setDate(start.getDate()+i);return d;});},[view]);
  const changeMonth=(delta:number)=>{const next=new Date(view.getFullYear(),view.getMonth()+delta,1);setView(next);setSelected(new Date(next.getFullYear(),next.getMonth(),Math.min(selected.getDate(),new Date(next.getFullYear(),next.getMonth()+1,0).getDate())));};
  const nextSlot=(()=>{const used=new Set(todayItems.map(a=>a.horario));for(let h=8;h<18;h++)for(const m of ['00','30']){const t=`${String(h).padStart(2,'0')}:${m}`;if(!used.has(t))return t;}return '—';})();
  return <div className="app"><header className="topbar"><img src="/logo-vitor-car.jpg" alt="Logo Vitor Car Auto Center" className="logo"/><div className="brand"><strong>VITOR CAR <span>AUTO CENTER</span></strong><small>AGENDA DE SERVIÇOS</small></div><div className="top-date">{fmt(today,{weekday:'short',day:'2-digit',month:'short',year:'numeric'})}</div></header>
    <main className="main"><div className="intro"><div><div className="eyebrow">ORGANIZAÇÃO DA OFICINA</div><h1>Agenda de serviços</h1><p>Planeje os atendimentos e acompanhe os veículos do dia.</p></div><button className="primary" onClick={openNew}>＋ Novo agendamento</button></div>
    {error&&<div className="error">{error}</div>}{!supabase&&<div className="warning"><b>Modo de demonstração:</b> conecte o Supabase para salvar os agendamentos no banco de dados. Neste modo, os dados ficam somente nesta sessão.</div>}
    <div className="layout"><section className="panel"><div className="panel-head"><strong className="month-title">{fmt(view,{month:'long',year:'numeric'})}</strong><div className="controls"><button className="icon-btn" aria-label="Mês anterior" onClick={()=>changeMonth(-1)}>‹</button><button className="secondary" onClick={()=>{setView(new Date(today.getFullYear(),today.getMonth(),1));setSelected(new Date(today));}}>Hoje</button><button className="icon-btn" aria-label="Próximo mês" onClick={()=>changeMonth(1)}>›</button></div></div><div className="weekdays">{['DOM','SEG','TER','QUA','QUI','SEX','SÁB'].map(x=><span key={x}>{x}</span>)}</div><div className="calendar">{calendarDays.map(d=>{const k=dateKey(d);const list=items.filter(a=>a.data===k).sort((a,b)=>a.horario.localeCompare(b.horario));return <button key={k} className={`day ${d.getMonth()!==view.getMonth()?'muted':''} ${k===dateKey(today)?'today':''} ${k===dateKey(selected)?'selected':''}`} onClick={()=>{setSelected(d);if(d.getMonth()!==view.getMonth())setView(new Date(d.getFullYear(),d.getMonth(),1));}}><span className="num">{d.getDate()}</span>{list.slice(0,2).map(a=><span key={a.id} className="event-dot">{a.horario} {a.cliente}</span>)}{list.length>2&&<span className="event-dot more">+{list.length-2} mais</span>}</button>;})}</div><div className="calendar-footer"><span className="legend"/> Dia com agendamento <span className="footer-note">Calendário atualizado automaticamente</span></div></section>
    <section className="panel"><div className="panel-head"><div><strong className="date-title">{fmt(selected,{weekday:'long',day:'numeric',month:'long'})}</strong><div className="subdate">{fmt(selected,{year:'numeric'})}</div></div><span className="count">{dayItems.length} {dayItems.length===1?'serviço':'serviços'}</span></div>{loading?<div className="empty">Carregando agenda…</div>:dayItems.length===0?<div className="empty"><div className="empty-icon">▦</div><strong>Nenhum serviço agendado</strong><span>Este dia está livre. Organize os próximos atendimentos.</span></div>:<div className="appointments">{dayItems.map(a=><article className="appointment" key={a.id}><div className="time">{a.horario}</div><div className="line"/><div><div className="appt-title">{a.servico}</div><div className="appt-meta"><b>{a.cliente}</b><br/>{a.veiculo}{a.placa?` · ${a.placa}`:''}{a.observacoes&&<><br/>{a.observacoes}</>}<br/><span className="status">{a.status}</span></div><div className="actions"><button className="tiny" onClick={()=>openEdit(a)}>Editar</button><button className="tiny delete" onClick={()=>void remove(a.id)}>Excluir</button></div></div></article>)}</div>}</section></div>
    <div className="stats"><div className="stat"><span>Agendamentos neste mês</span><strong>{monthItems.length}</strong></div><div className="stat"><span>Serviços hoje</span><strong>{todayItems.length}</strong></div><div className="stat"><span>Próximo horário livre</span><strong>{nextSlot}</strong></div></div><p className="footnote">Vitor Car Auto Center · Resende Costa – MG</p></main>
    {modal&&<div className="backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(false);}}><form className="modal" onSubmit={save}><h2>{editing?'Editar agendamento':'Novo agendamento'}</h2><p>Preencha os dados do atendimento da oficina.</p><div className="form-grid"><label className="full">Cliente *<input required value={draft.cliente} onChange={e=>setDraft({...draft,cliente:e.target.value})} placeholder="Nome do cliente"/></label><label>Veículo *<input required value={draft.veiculo} onChange={e=>setDraft({...draft,veiculo:e.target.value})} placeholder="Ex.: Onix 1.0 2020"/></label><label>Placa<input value={draft.placa} onChange={e=>setDraft({...draft,placa:e.target.value.toUpperCase()})} maxLength={8} placeholder="ABC-1D23"/></label><label>Data *<input type="date" required value={draft.data} onChange={e=>setDraft({...draft,data:e.target.value})}/></label><label>Horário *<input type="time" required value={draft.horario} onChange={e=>setDraft({...draft,horario:e.target.value})}/></label><label className="full">Serviço *<select required value={draft.servico} onChange={e=>setDraft({...draft,servico:e.target.value})}><option value="">Selecione o serviço</option>{services.map(s=><option key={s}>{s}</option>)}</select></label><label>Status<select value={draft.status} onChange={e=>setDraft({...draft,status:e.target.value})}>{['Agendado','Em andamento','Concluído','Cancelado'].map(s=><option key={s}>{s}</option>)}</select></label><label className="full">Observações<textarea rows={2} value={draft.observacoes} onChange={e=>setDraft({...draft,observacoes:e.target.value})} placeholder="Detalhes importantes do atendimento"/></label></div><div className="modal-actions"><button type="button" className="secondary" onClick={()=>setModal(false)}>Cancelar</button><button className="primary" type="submit">Salvar agendamento</button></div></form></div>}
  </div>;
}
