create table if not exists public.agendamentos (
  id uuid primary key default gen_random_uuid(),
  cliente text not null,
  veiculo text not null,
  placa text,
  servico text not null,
  data date not null,
  horario time not null,
  observacoes text,
  status text not null default 'Agendado' check (status in ('Agendado', 'Em andamento', 'Concluído', 'Cancelado')),
  created_at timestamptz not null default now()
);
alter table public.agendamentos enable row level security;
-- Política permissiva para protótipo. Antes de produção, configure login e políticas restritas.
create policy "agenda leitura anonima" on public.agendamentos for select to anon using (true);
create policy "agenda insercao anonima" on public.agendamentos for insert to anon with check (true);
create policy "agenda atualizacao anonima" on public.agendamentos for update to anon using (true) with check (true);
create policy "agenda exclusao anonima" on public.agendamentos for delete to anon using (true);
